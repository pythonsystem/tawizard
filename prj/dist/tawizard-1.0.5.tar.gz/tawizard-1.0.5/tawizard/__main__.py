if __name__ == '__main__':
    print('tawizard')

if __name__ == '__none__':
    print('tawizard')
